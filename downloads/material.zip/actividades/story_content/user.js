function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6joU3MKg28a":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

